<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> 
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Scripts -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/app.css')); ?>">
    <script src="<?php echo e(asset('build/assets/app-7e506d02.js')); ?>"></script>
    <link rel="stylesheet" href="/style.css">



</head>

<body class="font-['Poppins']">


    
    <header class="sticky top-0 z-10">
        <section>
            <div class="bg-white rounded-2xl shadow">
                <div class="mx-auto px-8 sm:px-6 lg:px-8">
                    <div class="flex justify-between h-24">
                        <div class="flex">
                            <a href="/home" class="flex-shrink-0 flex items-center">
                                <img class="h-14 w-14 rounded-full" src="image/icon.png" alt="ACS-LOGO">
                                <span class="text-orange-500 text-2xl ml-2 font-extrabold">ACS PRO-TECH</span>
                            </a>
                        </div>
                        <div class="hidden md:flex items-center">
                            <a href="#"
                                class="text-gray-700 hover:text-orange-500 px-3 py-2 rounded-md font-medium">About</a>
                            <a href="#"
                                class="text-gray-700 hover:text-orange-500 px-3 py-2 rounded-md  font-medium">Contact</a>
                            <?php if(auth()->guard()->guest()): ?>
                                <?php if(Route::has('login')): ?>
                                <?php endif; ?>

                                <?php if(Route::has('register')): ?>
                                <?php endif; ?>
                            <?php else: ?>
                                <p class="text-gray-700 text-sm mr-4">|</p>

                                <div class="relative inline-block">
                                    <button
                                        class="bg-gray-200 text-gray-700 font-semibold py-2 px-4 rounded inline-flex items-center"
                                        onclick="toggleDropdown()">
                                        <span> <?php echo e(Auth::user()->name); ?></span>
                                        <svg class="fill-current h-4 w-4 ml-2" xmlns="http://www.w3.org/2000/svg"
                                            viewBox="0 0 20 20">
                                            <path d="M6 8l4 4 4-4z"></path>
                                        </svg>
                                    </button>
                                    <div
                                        class="absolute hidden bg-white text-gray-700 rounded-xl border-gray-500 mt-2 px-4 shadow-md w-full text-center">
                                        <a href="/home" class="block px-4 py-2 hover:bg-gray-200"> <i
                                                class="fa fa-home py-auto" aria-hidden="true"></i>
                                            Home</a>
                                        <a href="/chart" class="block px-4 py-2 hover:bg-gray-200"><i
                                                class="fa fa-line-chart py-auto" aria-hidden="true"></i>
                                            Chart</a>
                                        <a href="" class="block px-4 py-2 hover:bg-gray-200"><i
                                                class="fa fa-gear py-auto" aria-hidden="true"></i>
                                            Settings</a>

                                        <br>
                                        <hr class="">

                                        <a href="<?php echo e(route('logout')); ?>"
                                            class="block px-4 py-2 text-red-500 hover:bg-gray-200"
                                            onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                            <i class="fa fa-sign-out py-auto" aria-hidden="true"></i>
                                            <?php echo e(__('Logout')); ?></a>


                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                </div>

                                <script>
                                    function toggleDropdown() {
                                        var dropdownMenu = document.querySelector('.absolute');
                                        dropdownMenu.classList.toggle('hidden');
                                    }
                                </script>

                            <?php endif; ?>

                        </div>

                        <button onclick="showHamburger()"
                            class="text-3xl md:hidden cursor-pointer text-black font-extrabold">
                            ☰
                        </button>
                    </div>
                </div>
            </div>

        </section>

        
        <section id="hamburger"
            class="bg-white w-1/2 text-center right-1 rounded-2xl shadow-md shadow-bottom-2xl border border-gray-300 -mt-5 absolute hidden lg:hidden">
            <nav>
                <div class="">
                    <div class="text-gray-700 px-2 pt-4 pb-3 space-y-1 sm:px-3">
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="/home" class="block px-3 py-4 rounded-md text-base font-medium hover:bg-yellow-200">
                                <?php echo e(Auth::user()->name); ?></a>

                            <a href="/home" class="block px-3 py-4 rounded-md text-base font-medium hover:bg-yellow-200">
                                <i class="fa fa-home py-auto" aria-hidden="true"></i>
                                Home
                            </a>

                            <a href="/chart" class="block px-3 py-4 rounded-md text-base font-medium hover:bg-yellow-200">
                                <i class="fa fa-line-chart py-auto" aria-hidden="true"></i>
                                Chart
                            </a>

                            <a href="#" class="block px-3 py-4 rounded-md text-base font-medium hover:bg-yellow-200">
                                <i class="fa fa-gear py-auto" aria-hidden="true"></i>
                                Settings
                            </a>

                            <br>
                            <a href="<?php echo e(route('logout')); ?>"
                                class="text-red-500 block px-3 py-4 rounded-md text-base font-medium hover:bg-yellow-200"
                                onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                                <i class="fa fa-gear py-auto" aria-hidden="true"></i>
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        <?php endif; ?>
                        </a>
                    </div>
                </div>
            </nav>
        </section>
    </header>
    


    <main class="">
        <?php echo $__env->yieldContent('content'); ?>
    </main>


    <script src="<?php echo e(asset('/js/hamburger.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\Ampere-Website\resources\views/layouts/inputlayout.blade.php ENDPATH**/ ?>